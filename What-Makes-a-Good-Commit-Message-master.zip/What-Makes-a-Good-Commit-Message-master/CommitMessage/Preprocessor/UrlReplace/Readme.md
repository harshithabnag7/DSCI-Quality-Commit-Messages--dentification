#### The script mainly gets the "messageIden" field, uses crawlers to get the content of commit on the web page.
#### Then replaces pull request, issue and commit links in commit message with "< pr_link >", "< issue_link >" and "< otherCommit_link >".

# Requirement

    sprapy

# Start

    run "runSpider.py"

#### or
    > scrapy crawl UrlReplace

