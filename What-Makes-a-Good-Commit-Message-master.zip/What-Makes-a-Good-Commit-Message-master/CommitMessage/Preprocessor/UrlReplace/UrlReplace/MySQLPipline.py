import pymysql.cursors
import logging

class MySQLPipeline(object):
    def __init__(self):
        
        self.connect = pymysql.connect(
            host='localhost',  
            port=3306,  
            db='github_repos',  # DB name
            user='root',  # User name
            passwd='****',  # DB password
            charset='utf8',  # DB charset
            use_unicode=True
        )

        
        self.cursor = self.connect.cursor()
        
        # Target table name
        self.tableName = 'message_raw_data_clean'

    def process_item(self, item, spider):
        sql = 'update '+ self.tableName + ' set messageIden = "' + item['commitMessage']+\
              '" where url like "%' + item['commitSha'] + '%"'
        try:
            
            logging.warning(sql)
            self.cursor.execute(sql)
            self.connect.commit()
        except:
    
            logging.warning("store error: "+sql)
            self.connect.rollback()

        return item 


    def close_spider(self, spider):
        self.cursor.close()
        self.connect.close()