# -*- coding: utf-8 -*-
import logging

import scrapy
import re
from UrlReplace.items import MessagecrawlerItem
import pymysql


def getCommitUrls(messagesTable):
    db = pymysql.Connect(host='localhost',
                         port=3306,
                         user='root',
                         passwd='tycmysql',
                         db='github_repos',
                         charset='utf8')
    cursor = db.cursor()

    urlDir = dict()
    sql = r"select id,url from " + messagesTable + " where `message_<iden>` is null"
    cursor.execute(sql)
    rows = cursor.fetchall()
    for row in rows:
        id = row[0]
        url = row[1]
        urlDir[id] = url
    cursor.close()
    db.close()
    return urlDir

def replaceUrl(url,text):
    if '/pull/' in url:
        return '<pr_link>'
    elif '/issues/' in url:
        return '<issue_link>'
    elif '/commit/' in url:
        return '<otherCommit_link>'
    else:
        return text


class InputmysqlSpider(scrapy.Spider):
    name = "UrlReplace"
    allowed_domains = ["www.github.com"]

    # The url of project commits
    # start_urls = ['https://github.com/square/okhttp/commits/master']
    # start_urls = ['https://github.com/spring-projects/spring-boot/commits/main?after=4ebac4cc6656d685fad45065a4970aaa6a520939+3339&branch=main']
    start_urls = ['https://github.com/junit-team/junit4/commits/main']
    # start_urls = ['https://github.com/square/retrofit/commits/master']
    # start_urls = ['https://github.com/apache/dubbo/commits/3.0']

    #
    # The part of the li tag 'data-url' attribute value that precedes sha, match the project to be crawled
    #
    # urlHead = '/square/okhttp/commit/'
    # urlHead = '/spring-projects/spring-boot/commit/'
    urlHead = '/junit-team/junit4/commits/'
    # urlHead = '/square/retrofit/commit/'
    # urlHead = '/apache/dubbo/commit/'


    def parse(self, response):
        item = MessagecrawlerItem()
        # The xpath of the commit list, which needs to be synchronized when there are updates
        commitMessageList = response.xpath('//li[@class="Box-row Box-row--focus-gray mt-0 d-flex js-commits-list-item js-navigation-item js-socket-channel js-updatable-content"]')
        for commitMessage in commitMessageList:
            commitURL = commitMessage.xpath('./@data-url').extract()[0]
            commitSHA = commitURL.replace(self.urlHead,'').split('/')[0]
            item['commitSha'] = commitSHA
            logging.warning(commitSHA)

            
            titleLinks = commitMessage.xpath('./div/p[@class="mb-1"]//a')
            title = ''
            content = ''
            for link in titleLinks:
                titleLinkUrl = link.xpath('./@href').extract()[0]
                titleText = link.xpath('.//text()').extract()[0]

                if titleText != '…':
                    if commitSHA in titleLinkUrl:
                        title += (titleText+' ')
                    else:
                        title += (replaceUrl(titleLinkUrl,titleText)+' ')
                else:
                    title += '…'

            # Get all the text contained in the body pre, and then replace the text contained in the link
            contentText = commitMessage.xpath('./div/div[@class="my-2 Details-content--hidden"]/pre//text()').extract()
            contentUrls = commitMessage.xpath('./div/div[@class="my-2 Details-content--hidden"]/pre//a')
            for conUrl in contentUrls:
                idenText = conUrl.xpath('.//text()').extract()
                if len(idenText) != 0:
                    idenText = idenText[0]
                    idenUrl = conUrl.xpath('./@href').extract()[0]
                    for i in range(0,len(contentText)):
                        if contentText[i] == idenText:
                            if not commitSHA in idenUrl:
                                contentText[i] = replaceUrl(idenUrl,idenText)
            for text in contentText:
                content += (text.replace('\n\n',' <enter> ').replace('\n',' ').replace('\t',' <tab> ') + ' ')

            if (content != '') and (not title.endswith('…')) and (not title.endswith('… ')) and (not content.startswith('…')):
                title += ' <enter> '
            # If the title is folded, remove the '…'
            if title.endswith('…') or title.endswith('… '):
                title = title[0:-2]
            if content.startswith('…'):
                content = content[1:]
            # Two line breaks for segmentation
            commitMessage = title + content

            item['commitMessage'] = commitMessage.replace('"','\'').replace(r'\t',r'\\t')
            yield item

        nextButtons = response.xpath('//div[@class="paginate-container"]/div/a')
        nextPageUrl = ''
        for button in nextButtons:
            if button.xpath('./text()').extract()[0] == 'Older':
                nextPageUrl = button.xpath('./@href').extract()[0]
        logging.warning(nextPageUrl)

        nextPageUrl = response.urljoin(nextPageUrl)
        yield scrapy.Request(url=nextPageUrl, callback=self.parse, dont_filter=True)

